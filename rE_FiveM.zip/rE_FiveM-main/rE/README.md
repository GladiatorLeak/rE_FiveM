# LoaderBase
This is just a simple cheat loader base made using ImGui.

Make sure to compile on x64 Debug and enjoy.
